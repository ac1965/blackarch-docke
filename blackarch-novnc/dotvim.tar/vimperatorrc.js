liberator.globalVariables.hBookmark_shortcuts = {
  hintsAdd: 'Ba',
  hintsComment: 'Bc',
  add: ['C'],
  comment: ['c'],
};
if (typeof hBookmark != 'undefined') {
  liberator.loadScript('chrome://hatenabookmark/content/vimperator/plugin/hatenabookmark.js', {
    __proto__: this
  });
}
